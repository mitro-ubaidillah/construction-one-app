
<div class="container">
    <header class="">
    <nav class="navbar navbar-expand-lg d-flex flex-wrap align-items-center justify-content-center justify-content-between py-4 mb-3">
        <a href="/" class="d-flex align-items-center col-md-2 mb-2 mb-md-0 text-dark text-decoration-none logo">
          <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" class="logo-nav">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse text-center" id="navbarSupportedContent">
            <ul class="navbar-nav col-sm-12 col-lg-9 mb-2 justify-content-center mb-md-0">
              <li class="nav-item"><a href="/" class="nav-link px-4 active">Home</a></li>
              <li class="nav-item"><a href="/about" class="nav-link px-4">About Us</a></li>
              <li class="nav-item"><a href="/projects" class="nav-link px-4">Projects</a></li>
            </ul>
            <div class="col-lg-3 col-sm-12 text-lg-end text-md-center">
              <a href="/contact" class="btn btn-one">Constac Us</a>
            </div>
        </div>
      
    </nav>
    </header>
</div><?php /**PATH D:\Portofolio\website\landingPage\construction\one-app\resources\views/partials/nav.blade.php ENDPATH**/ ?>